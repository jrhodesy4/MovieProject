function closeErrors(){
  $('.errors').css({
    display : 'none'
  })

}
